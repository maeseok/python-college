a = 17

def test():
    print(a)
    a = 13
    print(a)

test()


# global a (at line 5)
