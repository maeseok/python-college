f = open("test.txt", "w")
f.write("CS101 is fantastic!\n")
f.close()
#