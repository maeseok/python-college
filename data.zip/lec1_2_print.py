def print_message():
  print ("CS101 is fantastic!")
  print ("Programming is fun!")
  
print_message()
