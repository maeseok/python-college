def swap(a, b):
    a, b = b, a
    print(a, b)
    
x, y = 123, 456
swap(x, y)
print(x, y)



# return a, b (at line 4)
# x, y = swap(x, y) (replace line 6)