from cs1robots import*

load_world("./worlds/8queens.wld")

hubo = Robot(beepers = 1)

# hubo.move()

 