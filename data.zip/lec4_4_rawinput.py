raw_n = raw_input("Enter a positive integer> ")
n = int(raw_n)
for i in range(n):
  print ("*" * i)
  