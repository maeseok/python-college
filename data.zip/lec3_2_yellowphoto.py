from cs1media import *

purple = (128, 0, 128)
yellow = (255, 255, 0)

img = create_picture(100, 100, purple)
img.show()
img.set_pixels(yellow)
img.show()