from cs1media import *

img = load_picture("./cs101_students.jpg")
img.show()
