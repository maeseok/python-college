print ("CS101 is fantastic!")
print ("Programming is fun!")
