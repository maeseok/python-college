for i in range(4):
  print ("CS101 is fantastic!")
  print ("Programming is fun!")

